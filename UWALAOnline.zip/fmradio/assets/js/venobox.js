$(document).ready(function(){
  $('.venobox').venobox(); 
});